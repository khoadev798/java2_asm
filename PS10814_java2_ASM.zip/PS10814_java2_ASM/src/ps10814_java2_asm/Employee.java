/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ps10814_java2_asm;

/**
 *
 * @author khoa
 */
public class Employee {
    String empID;
    String name;
    int age;
    String email;
    float salary;
    
}
